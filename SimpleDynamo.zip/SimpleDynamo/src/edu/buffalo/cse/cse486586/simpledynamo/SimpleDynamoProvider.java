package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.concurrent.TimeoutException;



import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.SlidingDrawer;

public class SimpleDynamoProvider extends ContentProvider {

	SQLiteDatabase dynamodatabase;
	DatabaseHelper dynamodatabaseHelper;
	static String tablename;
	private static final String DB_FULL_PATH = "/data/data/edu.buffalo.cse.cse486586.simpledynamo/databases/MyDynamoDatabase";
	String myPort;
	static final int SERVER_PORT = 10000;
	static int dbVersion;
	String auth ;
	Uri contentUri;
	static String dataBaseName;
	static String KEY_FIELD;
	static String VALUE_FIELD;
	static String VERSION_FIELD;
	String msgPckt;
	int tempFlag=0;
	int tempFlag1=0;
	String globalSelection;
	boolean globalDelete = false;	
	boolean deleteflag=false;
	boolean recoveryMode = false;
	MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key","value"});
	MatrixCursor matrixCursor1;
	TreeMap <String,String>nodeList = new TreeMap<String, String>();
	ReadWriteLock readWritelock = new ReadWriteLock();
	public Object lockOnInsert = new Object();
	public Object lockOnQuery = new Object();
	public HashMap<String, String>personalKeyValuePair = new HashMap<String, String>();


	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];

			try{
				BufferedReader br;
				while(true){
					br = new BufferedReader(new InputStreamReader(serverSocket.accept().getInputStream()));
					String msgPacket = br.readLine();
					Log.e(msgPacket,"msg");
					String splitMsg[] = msgPacket.split("-");
					String msgType =splitMsg[0];
					String fromPort=splitMsg[1];
					String toPort=splitMsg[2];
					String key=splitMsg[3];
					String value = splitMsg[4];


					if(splitMsg[0].equals("insert into table")){
						readWritelock.lockWrite();
						insertIntoTbale(toPort,key,value);
						readWritelock.unlockWrite();

					}
					if(splitMsg[0].equals("global dump req")){
						getGlobalDump(fromPort,key,value);
						synchronized (this) {
							tempFlag=1;
						}
					}

					if(splitMsg[0].equals("query")){
						readWritelock.lockRead();
						getQuery(key,fromPort);
						readWritelock.unlockRead();
					}

					if(splitMsg[0].equals("query success")){
						synchronized (this) {
						//	if(!personalKeyValuePair.containsKey(key)){
						//		personalKeyValuePair.put(key, value);
								Log.e("into query success ", key + " "+value);
								matrixCursor1 = new MatrixCursor(new String[]{"key","value"});
								matrixCursor1.addRow(new Object[]{key,value});
								tempFlag1 = 1;
						//	}
						}

					}
					
					if(splitMsg[0].equals("recovery")){
						Log.e("recovery msg from "+fromPort,"in "+myPort);
						Cursor cursorToRecoveryMsg = query(contentUri, null, "@", null, null);
						String setOfKeys = null;
						String setOfValues =null;

						if(cursorToRecoveryMsg.getCount()>=1){
							while(cursorToRecoveryMsg.moveToNext()){
								int key1 =cursorToRecoveryMsg.getColumnIndex("key");
								int value1 = cursorToRecoveryMsg.getColumnIndex("value");
								String returnKey = cursorToRecoveryMsg.getString(key1);
								String returnValue = cursorToRecoveryMsg.getString(value1);

								if(setOfKeys ==null)
									setOfKeys = returnKey;
								else
									setOfKeys = setOfKeys+","+returnKey;

								if(setOfValues ==null)
									setOfValues = returnValue;
								else
									setOfValues = setOfValues+","+returnValue;

							}
						}
						if(setOfKeys!=null){
							client c=new client("keyvalue to recover",myPort,fromPort,setOfKeys,setOfValues);
							Thread thread = new Thread(c);
							thread.start();
						}
					}
					
					if(splitMsg[0].equals("keyvalue to recover")){
						recover(key,value);
					}
					
					if(splitMsg[0].equals("new global dump")){
									
						Cursor c2 = query(contentUri, null, "@", null, null);
						String setOfKeys = null;
						String setOfValues =null;

						if(c2.getCount()>=1){
							while(c2.moveToNext()){
								int key1 =c2.getColumnIndex("key");
								int value1 = c2.getColumnIndex("value");
								String returnKey = c2.getString(key1);
								String returnValue = c2.getString(value1);

								if(setOfKeys ==null)
									setOfKeys = returnKey;
								else
									setOfKeys = setOfKeys+","+returnKey;

								if(setOfValues ==null)
									setOfValues = returnValue;
								else
									setOfValues = setOfValues+","+returnValue;

							}
						}
						client c=new client("new global dump reply",myPort,fromPort,setOfKeys,setOfValues);
						Thread thread = new Thread(c);
						thread.start();
					}
					
					if(splitMsg[0].equals("new global dump reply")){
						/////////////////////////////////////////////////////////////////////////////
						
						String keys[] = key.split(",");
						String values[] = value.split(",");
						int size = keys.length;
						for(int i=0;i<size;i++){
							matrixCursor.addRow(new Object[]{keys[i],values[i]});
							
						}
						tempFlag =1;
					}

					if(splitMsg[0].equals("delete")){
						
						Log.e("global del",myPort);
						personalKeyValuePair.clear();
						int rowCount = dynamodatabase.delete(tablename, "1", null);
						if(myPort.equals(fromPort)){
							globalDelete = true;
							Log.e("Global delete","successful");
						}
						
					}
				}
			}catch(Exception e){
				Log.e("exception","exception");
			}
			return null;
		}	
	}
	
	public void recover(String keySet,String valueSet) throws NumberFormatException, NoSuchAlgorithmException{
		String keys[] = keySet.split(",");
		String values[] = valueSet.split(",");
		String prev1;
		String prev2;
		prev1 = findPrevious(Integer.toString((Integer.parseInt(myPort)/2)));
		prev2 = findPrevious(Integer.toString((Integer.parseInt(prev1)/2)));
		
		int size = keys.length;
		for(int i=0;i<size;i++){
			String owner = findOwener(keys[i]);
			if(owner.equals(myPort)||owner.equals(prev1)||owner.equals(prev2)){
				Log.e("recovery insert ", keys[i]+" "+values[i]);
				if(keys[i]!=null)
					insertIntoTbale(myPort, keys[i], values[i]);
			}
		}
	}
		
	public void insertIntoTbale(String toPort,String key,String value){
		//Log.e("inserting into "+toPort,key+" "+value);
		if(key!=null){
			ContentValues c=new ContentValues();
			c.put("key", key);
			c.put("value", value);
			dynamodatabase.insertWithOnConflict(tablename, null, c, SQLiteDatabase.CONFLICT_REPLACE);
		}
		//Log.e("inserted in to "+myPort,key+" "+value);
	}


	public void getQuery(String key,String fromPort){
		Cursor c= query(contentUri, null, "@", null, null);
		while(c.moveToNext()){
			Log.e("inside server query", key);
			int k =c.getColumnIndex("key");
			int v = c.getColumnIndex("value");
			String returnKey = c.getString(k);
			String returnValue = c.getString(v);
			if(returnKey.equals(key)){
				client c1=new client("query success",myPort,fromPort,returnKey,returnValue);
				Thread thread = new Thread(c1);
				thread.start();
				break;
				
			}
		}
	}


	public void getGlobalDump(String fromPort, String key,String value){

		if(!myPort.equals(fromPort)){
			Cursor c= query(contentUri, null, "@", null, null);
			String keysForGlobalDump = null,valuesForGlobalDump = null;
			Log.e("count",Integer.toString(c.getCount()));
			if(c.getCount()>=1){
				while(c.moveToNext()){
					int key1 =c.getColumnIndex("key");
					int value1 = c.getColumnIndex("value");
					String returnKey = c.getString(key1);
					String returnValue = c.getString(value1);
					if(key.equals("/")){
						if(keysForGlobalDump ==null)
							keysForGlobalDump = returnKey;
						else
							keysForGlobalDump = keysForGlobalDump+","+returnKey;

						if(valuesForGlobalDump ==null)
							valuesForGlobalDump = returnValue;
						else
							valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
					}
					else{
						if(keysForGlobalDump ==null)
							keysForGlobalDump = key+","+returnKey;
						else
							keysForGlobalDump = keysForGlobalDump+","+returnKey;

						if(valuesForGlobalDump ==null)
							valuesForGlobalDump = value+","+returnValue;
						else
							valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
					}
				}
			}
			else{
				if(key.equals("/")){
					if(keysForGlobalDump ==null)
						keysForGlobalDump = "/";
					if(valuesForGlobalDump ==null)
						valuesForGlobalDump = "/";
				}
				else{
					keysForGlobalDump = key;
					valuesForGlobalDump = value;
				}
			}
			String next = null;
			try {
				next = getNext(myPort);
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			client c3=new client("global dump req",fromPort,next,keysForGlobalDump,valuesForGlobalDump);
			Thread thread3 = new Thread(c3);
			thread3.start();
		}
		else{
			String[] splitKeysOfGlobalDump = key.split(",");
			String[] splitValuesOfGlobalDump = value.split(",");
			int size = splitKeysOfGlobalDump.length;
			for(int i=0;i<size;i++){
				matrixCursor.addRow(new Object[]{splitKeysOfGlobalDump[i],splitValuesOfGlobalDump[i]});
			}
			Log.e("hh","hh");
		}

	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		deleteflag=true;
		personalKeyValuePair.clear();
		int rowCount = dynamodatabase.delete(tablename, "1", null);
		
		String next1 = null,next2 = null,prev1 = null,prev2 = null;
		try{
			
			next1 = findOwener(Integer.toString(Integer.parseInt(myPort)/2));
			next2 = findOwener(Integer.toString(Integer.parseInt(next1)/2));
			prev1 = findPrevious(Integer.toString(Integer.parseInt(myPort)/2));
			prev2 = findPrevious(Integer.toString(Integer.parseInt(prev1)/2));
		}catch(Exception e){
			e.printStackTrace();
		}
		client c1=new client("delete",myPort,next1,"/","/");
		Thread thread1 = new Thread(c1);
		thread1.start();
		
		client c2=new client("delete",myPort,next2,"/","/");
		Thread thread2 = new Thread(c2);
		thread2.start();
		
		client c3=new client("delete",myPort,prev1,"/","/");
		Thread thread3 = new Thread(c3);
		thread3.start();
		
		client c4=new client("delete",myPort,prev2,"/","/");
		Thread thread4 = new Thread(c4);
		thread4.start();
		
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		synchronized (lockOnInsert) {
			String owerPort;
			String first;
			String second;
			try {
				owerPort = findOwener((String) values.get(KEY_FIELD));
				first = findOwener(Integer.toString(Integer.parseInt(owerPort)/2));
				second = findOwener(Integer.toString(Integer.parseInt(first)/2));
				msgPckt = "insert into destination"+"-"+myPort+"-"+owerPort+"-"+(String) values.get(KEY_FIELD)+"-"+(String) values.get(VALUE_FIELD);

				client c=new client("insert into table",myPort,owerPort,(String) values.get(KEY_FIELD),(String) values.get(VALUE_FIELD));
				Thread thread = new Thread(c);
				thread.start();

				client c1=new client("insert into table",myPort,first,(String) values.get(KEY_FIELD),(String) values.get(VALUE_FIELD));
				Thread thread1 = new Thread(c1);
				thread1.start();

				client c2=new client("insert into table",myPort,second,(String) values.get(KEY_FIELD),(String) values.get(VALUE_FIELD));
				Thread thread2 = new Thread(c2);
				thread2.start();
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			return null;

		}
	}

	public String findOwener(String key) throws NoSuchAlgorithmException{
		String hashOfKey = genHash(key);
		if(nodeList.higherEntry(hashOfKey)!=null)
			return nodeList.higherEntry(hashOfKey).getValue();
		else{
			return nodeList.firstEntry().getValue();
		}
	}
	
	public String findPrevious(String port) throws NumberFormatException, NoSuchAlgorithmException{
		if(nodeList.lowerEntry((genHash(port)))==null){
			return nodeList.lastEntry().getValue();
		}
		else
			return nodeList.lowerEntry((genHash(port))).getValue();
	}

	@Override
	public boolean onCreate() {

		tablename = "SimpleDynamoTable";
		dbVersion = 2;
		auth ="content://edu.buffalo.cse.cse486586.simpledynamo.provider";
		contentUri = Uri.parse("content://" + auth);
		dataBaseName = "MyDynamoDatabase";
		KEY_FIELD ="key";
		VALUE_FIELD = "value";
		VERSION_FIELD = "version";
		
		recoveryMode = false;
		if(isDataBaseCreatedAlready()){
			Log.e("db already exists for ","recovery mode on" );
			
			recoveryMode = true;
		}
		else
			Log.e("db creation "+myPort,"hiii" );
		
		
		
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		myPort = String.valueOf((Integer.parseInt(portStr) * 2));
		
		
		try {
			nodeList.put(genHash("5554"), "11108");
			nodeList.put(genHash("5556"), "11112");
			nodeList.put(genHash("5558"), "11116");
			nodeList.put(genHash("5560"), "11120");
			nodeList.put(genHash("5562"), "11124");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		dynamodatabaseHelper = new DatabaseHelper(getContext());
		dynamodatabase = dynamodatabaseHelper.getWritableDatabase();
		try {
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
			Log.e("server started at ", myPort);
		} catch (IOException e) {

			Log.e("hh", "Can't create a ServerSocket");
		}
		
		if(recoveryMode){
			// if recovery mode is on then send recovery msg to 1 next and 1 prev node.
			String first = null;
			String firstPrev = null;
			try{
				first = findOwener(Integer.toString(Integer.parseInt(myPort)/2));
				firstPrev = findPrevious(Integer.toString(Integer.parseInt(myPort)/2));
				Log.e("first is ",first);
				Log.e("prev is ",firstPrev);
			
			}catch(Exception e){
				Log.e("in recovery send exception","exception");
			}
			int rowCount = dynamodatabase.delete(tablename, "1", null);
			client c=new client("recovery",myPort,first,"/","/");
			Thread thread = new Thread(c);
			thread.start();
			
			client c1=new client("recovery",myPort,firstPrev,"/","/");
			Thread thread1 = new Thread(c1);
			thread1.start();
		}

		if (dynamodatabase == null) {
			return false;
		} else {
			
			return true;
		}

	}
	
	
private class ClientTask extends AsyncTask<String, Void, Void> {
		
		@Override
		protected Void doInBackground(String... msg) {
			String wholeMsg = msg[0];
			String splitMsg[]=wholeMsg.split("-");
			String msgType =splitMsg[0];
			String fromPort=splitMsg[1];
			String toPort=splitMsg[2];
			String key=splitMsg[3];
			try{
				Socket socket=new Socket("10.0.2.2",Integer.parseInt(toPort));
				PrintWriter toServer = null;
				toServer = new PrintWriter(socket.getOutputStream(), true);
				msgPckt = wholeMsg;
				toServer.println(msgPckt);
				socket.close();
			}catch(Exception e){
		
			}
			
			return null;
		}

	}
	
	
	
	private boolean isDataBaseCreatedAlready() {
		SQLiteDatabase checkDB = null;
		try {
			checkDB = SQLiteDatabase.openDatabase(DB_FULL_PATH, null,
					SQLiteDatabase.OPEN_READONLY);
			checkDB.close();
			return true;
		} catch (SQLiteException e) {
			return false;
		}
	}
	@Override
	public Cursor query(Uri uri, String[] projection, String selection,String[] selectionArgs, String sortOrder) {
		//synchronized (lockOnQuery) {
			SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
			qb.setTables(tablename);
			if(selection.equals("@")){
				Cursor cursor1 = null;
				cursor1 = qb.query(
						dynamodatabase, 
						projection, 
						null, 
						selectionArgs, 
						null, 
						null, 
						sortOrder);
				return cursor1;
			}
			else if(selection.equals("*")){
//				tempFlag=0;
//				Cursor cursor2 = null;
//				cursor2 = qb.query(
//						dynamodatabase, 
//						projection, 
//						null, 
//						selectionArgs, 
//						null, 
//						null, 
//						sortOrder);
//				String keysForGlobalDump = null;
//				String valuesForGlobalDump =null  ;
//				if(cursor2.getCount()>=1){
//					while(cursor2.moveToNext()){
//						int key =cursor2.getColumnIndex("key");
//						int value = cursor2.getColumnIndex("value");
//						String returnKey = cursor2.getString(key);
//						String returnValue = cursor2.getString(value);
//						if(keysForGlobalDump==null)
//							keysForGlobalDump =returnKey;
//						else
//							keysForGlobalDump = keysForGlobalDump+","+returnKey;
//
//						if(valuesForGlobalDump==null)
//							valuesForGlobalDump = returnValue;
//						else
//							valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
//					}
//				}
//				String next = null;
//				try {
//					next = getNext(myPort);
//				} catch (Exception e) {
//					e.printStackTrace();
//				} 
//				if(keysForGlobalDump!=null){
//					client c=new client("global dump req",myPort,next,keysForGlobalDump,valuesForGlobalDump);
//					Thread thread = new Thread(c);
//					thread.start();
//				}
//				else{
//					msgPckt = "global dump req"+"-"+myPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
//					client c=new client("global dump req",myPort,next,"/","/");
//					Thread thread = new Thread(c);
//					thread.start();
//				}
//				while(tempFlag==0){
//					;
//				}
				
				String next1 = null,next2 = null,prev1 = null,prev2 = null;
				try{
					next1 = findOwener(Integer.toString(Integer.parseInt(myPort)/2));
					next2 = findOwener(Integer.toString(Integer.parseInt(next1)/2));
					prev1 = findPrevious(Integer.toString(Integer.parseInt(myPort)/2));
					prev2 = findPrevious(Integer.toString(Integer.parseInt(prev1)/2));
				}catch(Exception e){
					e.printStackTrace();
				}
							
				tempFlag = 0;
				Cursor cursor2 = null;
				cursor2= qb.query(dynamodatabase, projection, null, selectionArgs, null, null, sortOrder);
				while(cursor2.moveToNext()){
					int key =cursor2.getColumnIndex("key");
					int value = cursor2.getColumnIndex("value");
					String returnKey = cursor2.getString(key);
					String returnValue = cursor2.getString(value);
					matrixCursor.addRow(new Object[]{returnKey,returnValue});
				}
				client c1=new client("new global dump",myPort,next1,"/","/");
				Thread thread1 = new Thread(c1);
				thread1.start();
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				client c2=new client("new global dump",myPort,next2,"/","/");
				Thread thread2 = new Thread(c2);
				thread2.start();
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				client c3=new client("new global dump",myPort,prev1,"/","/");
				Thread thread3 = new Thread(c3);
				thread3.start();
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				client c4=new client("new global dump",myPort,prev2,"/","/");
				Thread thread4 = new Thread(c4);
				thread4.start();
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				return matrixCursor;
			}	
			else{
				synchronized (this) {
					
////////////////////////commented For phase 4/////////////////////////////////////////////////////////////////////////
//				try {
//					Thread.sleep(2000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
				matrixCursor1 = sendQueryReq(qb,selection,projection,sortOrder,selectionArgs);
			//	Log.e("returning matrix cursor", "hiii");
				
				while(matrixCursor1.moveToNext()){
					int key =matrixCursor1.getColumnIndex("key");
					int value = matrixCursor1.getColumnIndex("value");
					String returnKey = matrixCursor1.getString(key);
					String returnValue = matrixCursor1.getString(value);
					Log.e("returning values is ",returnKey+" "+returnValue);
				}
				return matrixCursor1;
				}
			}

	//	}
	}

	public MatrixCursor sendQueryReq(SQLiteQueryBuilder qb,String selection,String[] projection,String sortOrder,String[] selectionArgs){
		tempFlag1 = 0;
		String destination = null;
		String first = null;
		String second = null;
		try {
			destination = findOwener(selection);
			first = findOwener(Integer.toString(Integer.parseInt(destination)/2));
			second = findOwener(Integer.toString(Integer.parseInt(first)/2));
			
			
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Log.e("destination is ",destination);
		Log.e("key for query is ",selection);
		/*if(destination.equals(myPort) || first.equals(myPort)|| second.equals(myPort)){
			Log.e("query self ",selection);
			Cursor cursor1 = null;
			cursor1 = qb.query(
					dynamodatabase, 
					projection, 
					null, 
					selectionArgs, 
					null, 
					null, 
					sortOrder);

			String returnKey = null;
			String returnValue = null;
			while(cursor1.moveToNext()){

				int k =cursor1.getColumnIndex("key");
				int v = cursor1.getColumnIndex("value");
				returnKey = cursor1.getString(k);
				returnValue = cursor1.getString(v);
				if(returnKey.equals(selection)){
					matrixCursor1 = new MatrixCursor(new String[]{"key","value"});
					matrixCursor1.addRow(new Object[]{returnKey,returnValue});
					tempFlag1 = 1;
					break;
				}
			}
			
		}

		else{*/
			
			ArrayList<String>nodesToSend = new ArrayList<String>();
			nodesToSend.add(destination);
			nodesToSend.add(first);
			nodesToSend.add(second);
			for(String node : nodesToSend){
				client c=new client("query",myPort,node,selection,"/");
				Thread thread = new Thread(c);
				thread.start();
				
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(tempFlag1==1)
					break;
	//		}
//			Log.e("sending query to "+destination,selection);
//			client c=new client("query",myPort,destination,selection,"/");
//			Thread thread = new Thread(c);
//			thread.start();
//			
//			Log.e("sending query to first "+first,selection);
//			client c1=new client("query",myPort,first,selection,"/");
//			Thread thread1 = new Thread(c1);
//			thread1.start();
//			
//			Log.e("sending query to second "+second,selection);
//			client c2=new client("query",myPort,second,selection,"/");
//			Thread thread2 = new Thread(c2);
//			thread2.start();
			
			
		}

	//////////////////////// commented For phase 4/////////////////////////////////////////////////////////////////////////	
		
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

//		while(tempFlag1==0){
//			;
//		}
		return matrixCursor1;
	}

	/*public MatrixCursor getQuery(SQLiteQueryBuilder qb,String selection,String[] projection,String sortOrder,String[] selectionArgs){
		globalSelection = new String();
		globalSelection = selection;
		tempFlag1=0;
		Cursor cursor3 = null;
		 cursor3 = qb.query(
				dynamodatabase, 
				projection, 
				null, 
				selectionArgs, 
				null, 
				null, 
				sortOrder);


		String keysForGlobalDump = null;
		String valuesForGlobalDump =null  ;
		if(cursor3.getCount()>=1){
			while(cursor3.moveToNext()){
				int key =cursor3.getColumnIndex("key");
				int value = cursor3.getColumnIndex("value");
				String returnKey = cursor3.getString(key);
				String returnValue = cursor3.getString(value);
				if(keysForGlobalDump==null)
					keysForGlobalDump =returnKey;
				else
					keysForGlobalDump = keysForGlobalDump+","+returnKey;

				if(valuesForGlobalDump==null)
					valuesForGlobalDump = returnValue;
				else
					valuesForGlobalDump = valuesForGlobalDump+","+returnValue;
			}
		}
		String next = null;
		try {
			next = getNext(myPort);
		} catch (Exception e) {
			e.printStackTrace();
		} 

		if(keysForGlobalDump!=null){
			msgPckt = "global dump req"+"-"+myPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
			client c=new client("global dump req",myPort,next,keysForGlobalDump,valuesForGlobalDump);
			Thread thread = new Thread(c);
			thread.start();
		}
		else{
			msgPckt = "global dump req"+"-"+myPort+"-"+next+"-"+keysForGlobalDump+"-"+valuesForGlobalDump+"-"+"/"+"-"+"/";
			client c=new client("global dump req",myPort,next,"/","/");
			Thread thread = new Thread(c);
			thread.start();
		}

		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(tempFlag1==0){
			;
		}
		return matrixCursor1;

	}*/




	@Override
	public int update(Uri uri, ContentValues values, String selection,String[] selectionArgs) {
		return 0;
	}

	private String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}

	String getNext(String port) throws NumberFormatException, NoSuchAlgorithmException{

		if(nodeList.higherEntry(genHash (Integer.toString(Integer.parseInt(port)/2))  )!=null)
			return nodeList.higherEntry(genHash (Integer.toString(Integer.parseInt(port)/2))  ).getValue();
		else
			return nodeList.firstEntry().getValue();
	}

	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, dataBaseName, null, dbVersion);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			//	db.execSQL("CREATE TABLE " + tablename + "(" + KEY_FIELD + " text primary key, " + VALUE_FIELD + " text not null, " + VERSION_FIELD +" text );");
			db.execSQL("CREATE TABLE " + tablename + "(" + KEY_FIELD + " text primary key, " + VALUE_FIELD + " text not null );");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("DROP TABLE IF EXISTS " + tablename);
			onCreate(db);
		}
	}


	class client implements Runnable{
		String type,fromPort,toPort,key,value;

		public client(String type,String fromPort,String toPort,String key,String value) {
			this.type=type;
			this.fromPort = fromPort;
			this.toPort=toPort;
			this.key=key;
			this.value=value;
		}
		public void run() {
			String msgPacket = type+"-"+fromPort+"-"+toPort+"-"+key+"-"+value;
		//	Log.e("msg is ", msgPacket);
			
			String wholeMsg = msgPacket;
			String splitMsg[]=wholeMsg.split("-");
			String msgType =splitMsg[0];
			String fromPort=splitMsg[1];
			String toPort=splitMsg[2];
			String key=splitMsg[3];

			Socket socket = null;
			try {
				socket = new Socket("10.0.2.2",Integer.parseInt(toPort));
			//	socket.setSoTimeout(500);
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (SocketException t) {
				Log.e("socket timeout ", "socket timeout");
				t.printStackTrace();
				
			}catch(IOException e){
				e.printStackTrace();
				
			}
			PrintWriter toServer = null;
			try {
				toServer = new PrintWriter(socket.getOutputStream(), true);
				DataInputStream din = new DataInputStream(socket.getInputStream() );
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			msgPckt = wholeMsg;
			toServer.println(msgPckt);
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} 
	}
	
	//http://tutorials.jenkov.com/java-concurrency/read-write-locks.html
	public class ReadWriteLock{

		private int readers       = 0;
		private int writers       = 0;
		private int writeRequests = 0;

		public synchronized void lockRead() throws InterruptedException{
			while(writers > 0 || writeRequests > 0){
				wait();
			}
			readers++;
		}

		public synchronized void unlockRead(){
			readers--;
			notifyAll();
		}

		public synchronized void lockWrite() throws InterruptedException{
			writeRequests++;

			while(readers > 0 || writers > 0){
				wait();
			}
			writeRequests--;
			writers++;
		}

		public synchronized void unlockWrite() throws InterruptedException{
			writers--;
			notifyAll();
		}
	}



}
