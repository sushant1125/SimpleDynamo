/** Automatically generated file. DO NOT MODIFY */
package edu.buffalo.cse.cse486586.simpledynamo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}